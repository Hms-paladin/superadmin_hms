import React from "react";

class Dashboard extends React.Component{
    render(){
        return(
            <div>
            <h1>Dashboard</h1>
            </div>
        )
    }
}

export default Dashboard;